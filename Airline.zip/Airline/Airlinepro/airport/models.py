from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

class Flight(models.Model):
    flight_id = models.CharField(max_length=10, primary_key=True)
    dep_airport = models.CharField(max_length=100)
    dep_date = models.DateField()
    dep_time = models.TimeField()
    arr_airport = models.CharField(max_length=100)
    arr_date = models.DateField()
    arr_time = models.TimeField()
    flight_author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='flights')
    flight_image = models.ImageField(upload_to='post/images/')



    def __str__(self):
        return self.flight_id


