from django.apps import AppConfig


class AirportConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'airport'
