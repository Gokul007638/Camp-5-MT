
from django.shortcuts import render, get_object_or_404
from .models import Flight
from django.shortcuts import render,get_object_or_404,HttpResponse,redirect
from django.contrib.auth import authenticate, login as auth_login
from .forms import MyLoginForm,FlightAddForm,FlightEditForm
from django.contrib.auth import logout

def mainpage(request):
    return render(request, 'user_account/mainpage.html')
def flights_list(request):
    searchTerm=request.GET.get('searchflight')
    if searchTerm:
        flights_list=Flight.objects.filter(flight_id__icontains=searchTerm)
    else:
        flights_list=Flight.objects.all()
    return render(request,'flights.html',{'searchTerm':searchTerm,'flights_list':flights_list})

def flight_details_view(request, passed_id):
    flight_details = get_object_or_404(Flight, flight_id=passed_id)
    return render(request, 'flightdetails.html', {'flight_details': flight_details})




def user_login(request):
    if request.method == 'POST':
        login_form = MyLoginForm(request.POST)
        if login_form.is_valid():
            cleaned_data = login_form.cleaned_data
            auth_user = authenticate(request, username=cleaned_data['username'], password=cleaned_data['password'])
            if auth_user is not None:
                auth_login(request, auth_user)
                if auth_user.is_superuser:
                    # Redirect admin users to home_path
                    return redirect('home_path')
                else:

                    return HttpResponse('Not authenticated')
            else:
                return render(request, 'user_account/login_form.html', {
                    'login_form': login_form,
                    'error': 'Invalid credentials'
                })
    else:
        login_form = MyLoginForm()

    return render(request, 'user_account/login_form.html', {'login_form': login_form})

def add_flight(request):
    add_flight_form=FlightAddForm(request.POST,request.FILES)
    if request.method=='POST':
        if add_flight_form.is_valid():
            new_flight=add_flight_form.save(commit=False)
            print(new_flight)
            print(request.user)
            new_flight.flight_author=request.user
            new_flight.save()
            return redirect('home_path')
        else:
            add_flight_form=FlightAddForm()
    return render(request, 'account/add_flight.html', {'add_post_form':  add_flight_form})

def edit_flight(request, flight_id):
    flight = get_object_or_404(Flight, flight_id=flight_id)  # Fetch the flight instance
    if request.method == 'POST':
        edit_flight_form = FlightEditForm(request.POST, request.FILES, instance=flight)
        if edit_flight_form.is_valid():
            edit_flight_form.save()  # Save the changes
            return redirect('home_path')  # Redirect to the desired page
    else:
        edit_flight_form = FlightEditForm(instance=flight)  # Pre-populate the form with flight data

    return render(request, 'account/edit_flight.html', {'edit_flight_form': edit_flight_form, 'flight': flight})


# def delete_post(request,passed_id):
#     post_details = get_object_or_404(Flight, id=passed_id)
#     post_details.delete()
#     return redirect('home_path')


def delete_flight(request, flight_id):
    flight = get_object_or_404(Flight, flight_id=flight_id)  # Fetch the flight instance

    if request.method == 'POST':
        flight.delete()  # Delete the flight
        return redirect('home_path')  # Redirect to the desired page

    return render(request, 'account/delete_flight.html', {'flight': flight})

def user_logout(request):
    logout(request)
    return redirect('login')