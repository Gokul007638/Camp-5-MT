from django import forms
from django.shortcuts import render,get_object_or_404,HttpResponse,redirect
from .models import User,Flight

class MyLoginForm(forms.Form):
    username=forms.CharField()
    password=forms.CharField(widget=forms.PasswordInput)


class FlightAddForm(forms.ModelForm):
    class Meta:
        model = Flight
        fields = (
            'flight_id',
            'dep_airport',
            'dep_date',
            'dep_time',
            'arr_airport',
            'arr_date',
            'arr_time',
            'flight_image',
        )

class FlightEditForm(forms.ModelForm):
    class Meta:
        model = Flight
        fields = (
            'flight_id',
            'dep_airport',
            'dep_date',
            'dep_time',
            'arr_airport',
            'arr_date',
            'arr_time',
            'flight_image',
        )

