
# from django.urls import path
# from .views import flights_list,flight_details_view
#
# urlpatterns = [
#     path('',flights_list,name='home_path'),
#     path('airport/<int:passed_id>/',flight_details_view,name='details_path')
# ]


from django.urls import path
from .views import flights_list, flight_details_view,user_login,mainpage,add_flight,edit_flight,delete_flight, user_logout





urlpatterns = [
    path('', flights_list, name='home_path'),
    path('airport/<int:passed_id>/', flight_details_view, name='details_path'),
    path('login/', user_login, name='login'),
    path('mainpage/', mainpage, name='mainpage'),
    path('account/add_flight/',add_flight,name='add_flight'),
    path('account/edit_flight/<int:flight_id>/', edit_flight, name='edit_flight'),
    path('account/delete_flight/<int:flight_id>/', delete_flight, name='delete_flight'),
    path('account/logout/', user_logout, name='logout'),

]


# urlpatterns = [
#     path('home_path/', flights_list, name='home_path'),
#     path('airport/<int:passed_id>/', flight_details_view, name='details_path'),
#     path('login/', user_login, name='login'),
#     path('', mainpage, name='mainpage'),
#
# ]